# hello_world - log "Hello World!"
from csclient import EventingCSClient
import time
cp = EventingCSClient('hello_world')
cp.log('Hello World!')
while True:
    time.sleep(1)
